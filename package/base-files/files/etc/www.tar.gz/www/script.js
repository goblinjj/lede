function toggleSidebar() {
  const sidebar = document.querySelector(".sidebar");
  const overlay = document.querySelector(".overlay");
  sidebar.classList.toggle("active");
  overlay.style.display = sidebar.classList.contains("active")
    ? "block"
    : "none";

  // 移动端主内容偏移
  if (window.innerWidth <= 768) {
    document.documentElement.style.overflow = sidebar.classList.contains(
      "active"
    )
      ? "hidden"
      : "auto";
  }
}
function clickMenu() {
  const sidebar = document.querySelector(".sidebar");
  const overlay = document.querySelector(".overlay");
  sidebar.classList.remove("active");
  overlay.style.display = "none";
  document.documentElement.style.overflow = "auto";
}
// 窗口大小变化监听
window.addEventListener("resize", () => {
  if (window.innerWidth > 768) {
    document.querySelector(".sidebar").classList.remove("active");
    document.querySelector(".overlay").style.display = "none";
    document.documentElement.style.overflow = "auto";
  }
});

getData = () => {
  const url = "/cgi-bin/status";
  fetch(url)
    .then((response) => response.json())
    .then((data) => {
      let {
        sn,
        up,
        expires,
        time,
        wifi1s,
        wifi2s,
        wifi1ssid,
        wifi2ssid,
        wifi1key,
        wifi2key,
        ip,
        netmask,
        dhcp,
        nodes,
        checkedNode,
        nodeMode,
      } = data;
      document.getElementById("sn").innerText = sn;
      document.getElementById("up").innerText = up;
      const expiresElement = document.getElementById("expires");
      const expiresDate = new Date(expires);
      expiresDate.setDate(expiresDate.getDate() + 1); // 增加 1 天
      if (expires === "未激活" || expiresDate < new Date()) {
        expiresElement.style.color = "red";
      } else {
        expiresElement.style.color = "green";
      }
      expiresElement.innerText = expires;
      document.getElementById("time").innerText = time;
      document.getElementById("ssid-input1").value = wifi1ssid;
      document.getElementById("ssid-input2").value = wifi2ssid;
      document.getElementById("password-input1").value = wifi1key;
      document.getElementById("password-input2").value = wifi2key;
      document.getElementById("wifi1").checked = !wifi1s;
      document.getElementById("wifi2").checked = !wifi2s;
      document.getElementById("ip-input").value = ip;
      document.getElementById("mask-select").value = netmask;
      document.getElementById("dhcp").checked = !dhcp;

      const nodeContent = document.getElementById("nodesContent");
      nodeContent.innerHTML = ""; // 清空节点内容
      nodes.forEach((node) => {
        nodeContent.innerHTML += `
          <input type="radio" name="region" value="${node.key}" id="nodeid-${
          node.value
        }" ${
          node.value === checkedNode || node.key === checkedNode
            ? "checked"
            : ""
        }/>
          <label for="nodeid-${node.value}">${node.value}</label>
        `;
      });
      const nodeModesContent = document.getElementById("nodeModesContent");
      if (checkedNode === "nil") {
        nodeModesContent
          .querySelectorAll('input[type="radio"]')
          .forEach((radio) => {
            if (radio.value === "direct") {
              radio.checked = true;
            } else {
              radio.checked = false;
            }
          });
      } else {
        nodeModesContent
          .querySelectorAll('input[type="radio"]')
          .forEach((radio) => {
            if (radio.value === nodeMode) {
              radio.checked = true;
            } else {
              radio.checked = false;
            }
          });
      }
    })
    .catch((error) => console.error("Error fetching data:", error));
};
commitnode = (btn) => {
  // 获取并锁定按钮
  lockButton(btn);
  // 获取所有输入值
  const nodesContent = document.getElementById("nodesContent");
  const nodeModesContent = document.getElementById("nodeModesContent");
  const selectedNode = nodesContent.querySelector(
    'input[name="region"]:checked'
  );
  const selectedNodeMode = nodeModesContent.querySelector(
    'input[name="mode"]:checked'
  );
  const selectedNodeValue = selectedNode ? selectedNode.value : null;
  const selectedNodeModeValue = selectedNodeMode
    ? selectedNodeMode.value
    : null;

  fetch(
    `/cgi-bin/commitnode?node=${selectedNodeValue}&mode=${selectedNodeModeValue}`
  )
    .then((response) => response.json())
    .finally(() => {
      getData(); // 刷新数据
      // 解锁按钮
      resetButton(btn);
    });
};

commitnetwork = (btn) => {
  // 获取所有输入值
  const ip = document.getElementById("ip-input").value;
  const mask = document.getElementById("mask-select").value;
  const dhcp = document.getElementById("dhcp").checked ? "0" : "1";

  // 验证输入
  if (
    !/^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/.test(
      ip
    )
  ) {
    alert(languages[currentLanguage].ipValidate);
    return;
  }
  if (!/^(\d{1,3}\.){3}\d{1,3}$/.test(mask)) {
    alert(languages[currentLanguage].maskValidate);
    return;
  }
  // 获取并锁定按钮
  lockButton(btn);

  // 构建请求URL
  const params = new URLSearchParams({ ip, mask, dhcp });
  const url = `/cgi-bin/commitnetwork?${params.toString()}`;

  // 发送请求
  fetch(url)
    .then((response) => response.json())
    .finally(() => {
      getData(); // 刷新数据
      // 解锁按钮
      resetButton(btn);
    });

  setTimeout(() => {
    // 刷新页面
    window.location.href = "http://" + ip + "/index.html";
  }, 5000);
};
commitwifi = (btn) => {
  // 获取所有输入值
  const wifi1s = document.getElementById("wifi1").checked ? "0" : "1";
  const wifi2s = document.getElementById("wifi2").checked ? "0" : "1";
  const wifi1ssid = document.getElementById("ssid-input1").value;
  const wifi2ssid = document.getElementById("ssid-input2").value;
  const wifi1key = document.getElementById("password-input1").value;
  const wifi2key = document.getElementById("password-input2").value;

  // 验证输入
  if (!/^[a-zA-Z0-9-_]{1,32}$/.test(wifi1ssid)) {
    alert(languages[currentLanguage].wifiSSIDValidate);
    return;
  }
  if (!/^[a-zA-Z0-9-_]{1,32}$/.test(wifi2ssid)) {
    alert(languages[currentLanguage].wifiSSIDValidate);
    return;
  }
  if (!/^[\u4e00-\u9fa5a-zA-Z0-9]{8,20}$/.test(wifi1key)) {
    alert(languages[currentLanguage].wifiValidate);
    return;
  }
  if (!/^[\u4e00-\u9fa5a-zA-Z0-9]{8,20}$/.test(wifi2key)) {
    alert(languages[currentLanguage].wifiValidate);
    return;
  }
  // 获取并锁定按钮
  lockButton(btn);

  // 构建请求URL
  const params = new URLSearchParams({
    wifi1s,
    wifi2s,
    wifi1ssid,
    wifi2ssid,
    wifi1key,
    wifi2key,
  });

  const url = `/cgi-bin/commitwifi?${params.toString()}`;

  // 发送请求
  fetch(url)
    .then((response) => response.json())
    .finally(() => {
      getData(); // 刷新数据
      // 解锁按钮
      resetButton(btn);
    });
};

function lockButton(btn) {
  const allButtons = document.querySelectorAll('input[type="button"]');
  allButtons.forEach((button) => {
    button.disabled = true;
  });
  btn.classList.add("loading");
  const loadingCircle = btn.parentElement.querySelector(".loadingCircle");
  if (loadingCircle) {
    loadingCircle.style.display = "block";
  }
  const btnLang = btn.getAttribute("data-lang");
  if (btnLang === "save") {
    btn.value = languages[currentLanguage].saving;
  } else if (btnLang === "update") {
    btn.value = languages[currentLanguage].updating;
  } else {
    btn.value = languages[currentLanguage].saving;
  }
}

var t;
// 重置按钮状态的函数
function resetButton(btn) {
  clearTimeout(t);
  const allButtons = document.querySelectorAll('input[type="button"]');
  allButtons.forEach((button) => {
    button.disabled = false;
  });
  btn.classList.remove("loading");
  const loadingCircle = btn.parentElement.querySelector(".loadingCircle");
  if (loadingCircle) {
    loadingCircle.style.display = "none";
  }
  const btnLang = btn.getAttribute("data-lang");
  if (btnLang === "save") {
    btn.value = languages[currentLanguage].saveSuccess;
    t = setTimeout(() => {
      btn.value = languages[currentLanguage].save;
    }, 3000);
  } else if (btnLang === "update") {
    btn.value = languages[currentLanguage].updateSuccess;
    t = setTimeout(() => {
      btn.value = languages[currentLanguage].update;
    }, 1000);
  }
}
function changeLanguage(lang) {
  currentLanguage = lang;
  document.documentElement.lang = lang;
  updateContent();
}

function updateContent() {
  // 更新标题
  document.title = languages[currentLanguage].title;

  // 更新菜单项
  document.querySelector('[href="#dashboard"]').textContent =
    languages[currentLanguage].dashboard;
  document.querySelector('[href="#nodes"]').textContent =
    languages[currentLanguage].nodes;
  document.querySelector('[href="#ethernet"]').textContent =
    languages[currentLanguage].ethernet;
  document.querySelector('[href="#wireless"]').textContent =
    languages[currentLanguage].wireless;

  // 更新所有带data-lang属性的元素
  document.querySelectorAll("[data-lang]").forEach((element) => {
    const key = element.getAttribute("data-lang");
    if (languages[currentLanguage][key]) {
      if (element.tagName === "INPUT" && element.type === "button") {
        element.value = languages[currentLanguage][key];
      } else if (element.tagName === "INPUT" && element.placeholder) {
        element.placeholder = languages[currentLanguage][key];
      } else {
        element.textContent = languages[currentLanguage][key];
      }
    }
  });
}
function logout() {
  localStorage.removeItem("isLoggedIn"); // 清除登录态
  localStorage.removeItem("loginTime");
  window.location.href = "login.html"; // 跳转到登录页面
}

function openChangePasswordModal() {
  document.getElementById("changePasswordModal").style.display = "flex";
}

function closeChangePasswordModal() {
  // 清空输入框
  document.getElementById("newPassword").value = "";
  document.getElementById("confirmPassword").value = "";
  document.getElementById("changePasswordModal").style.display = "none";
}
function updateExpires(btn) {
  lockButton(btn);
  const url = `/cgi-bin/expires`;
  fetch(url)
    .then((response) => response.json())
    .then((data) => {
      getData();
    })
    .finally(() => {
      resetButton(btn);
    });
}

document
  .getElementById("changePasswordForm")
  .addEventListener("submit", function (e) {
    e.preventDefault();

    const newPassword = document.getElementById("newPassword").value;
    const confirmPassword = document.getElementById("confirmPassword").value;

    if (newPassword !== confirmPassword) {
      alert(languages[currentLanguage].confirmPasswordMismatch);
      return;
    }

    // 调用后端接口修改密码
    fetch("/cgi-bin/changepass", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password: newPassword }),
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.code == 0) {
          alert(languages[currentLanguage].changepass);
          closeChangePasswordModal();
        }
      });
  });
// 页面加载时初始化语言
document.addEventListener("DOMContentLoaded", () => {
  // 在文件开头添加
  let currentLanguage = "zh-TW";

  const isLoggedIn = localStorage.getItem("isLoggedIn") === "true";
  const loginTime = parseInt(localStorage.getItem("loginTime"), 10);
  const timeout = 30 * 60 * 1000; // 登录超时时间（30分钟）

  if (!isLoggedIn || Date.now() - loginTime > timeout) {
    alert(languages[currentLanguage].loginerror); // 提示登录超时
    localStorage.removeItem("isLoggedIn"); // 清除登录态
    localStorage.removeItem("loginTime");
    window.location.href = "login.html"; // 跳转到登录页面
  }

  getData();
  changeLanguage(currentLanguage);
});
