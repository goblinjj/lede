#!/usr/bin/lua

-- CGI 头部
print("Content-Type: application/json\n")

-- 这里简单实现 connect_status 的核心逻辑
local function connect_status()
    local url = os.getenv("QUERY_STRING") or ""
    url = url:match("url=([^&]+)") or "www.baidu.com"
    url = url:gsub("%%3A", ":"):gsub("%%2F", "/") -- 解码部分常见字符

    -- 这里只做最基础的 curl 检测
    local cmd = string.format("/usr/bin/curl --connect-timeout 3 -o /dev/null -I -sk -w '%%{http_code}:%%{time_starttransfer}' http://%s", url)
    local result = io.popen(cmd):read("*a") or ""
    local code, use_time = result:match("(%d+):([%d%.]+)")
    local e = {}
    if code then
        e.use_time = string.format("%.2f", tonumber(use_time or 0) * 1000)
        e.ping_type = "curl"
    else
        e.use_time = ""
    end
    -- 输出 JSON
    print(string.format('{"use_time":"%s","ping_type":"%s"}', e.use_time or "", e.ping_type or ""))
end

connect_status()